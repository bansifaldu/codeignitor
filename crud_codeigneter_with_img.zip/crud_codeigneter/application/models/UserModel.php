 <?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
  
class UserModel extends CI_Model
{
    function get_user($username,$password){
		$query = $this->db->get('users');
        $query = $this->db->get_where('users', array('user_name' => $username,'user_password' => $password));
		return $query;	
	}

}