<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	<link href="<?php echo base_url().'assets/css/bootstrap.css'?>" rel="stylesheet" type="text/css">
	<link href="<?php echo base_url().'assets/css/datatables.css'?>" rel="stylesheet" type="text/css">
</head>
<body>
	<div class="container">

	  <div class=" justify-content-md-center" style=" margin-top: 100px;border:none;">
	    <div class="col col-lg-8">
	    	
	    	<a href="<?php echo site_url('product');?>" class="btn btn-success btn-sm">Product Page</a><hr/>
	      	
	    </div>
	  </div>

	</div>
	
</body>
</html>