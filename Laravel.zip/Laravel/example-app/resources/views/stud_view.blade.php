<html>
   
   <head>
      <title>View Student Records</title>
   </head>
   
   <body>
   <div class=col-md-12>
   @include('stud_create') 

 </div>

      <table border = 1>
         <tr>
            <td>ID</td>
            <td>Name</td>
            <td>Edit</td>
            <td>Delete</td>
         </tr>
         @foreach ($users as $user)
         <tr>
            <td>{{ $user->Id }}</td>
            <td>{{ $user->Name }}</td>
            <td><a href = 'edit/{{ $user->Id }}'>Edit</a></td>
            <td><a href = 'delete/{{ $user->Id }}'>Delete</a></td>

         </tr>
         @endforeach
      </table>
   </body>
</html>