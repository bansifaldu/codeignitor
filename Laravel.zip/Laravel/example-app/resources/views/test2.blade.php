<html>
   <body>
      <h1><?php echo $name; ?></h1>
   </body>
</html>