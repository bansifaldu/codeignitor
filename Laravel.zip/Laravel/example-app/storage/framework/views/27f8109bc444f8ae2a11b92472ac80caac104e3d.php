<html>
   
   <head>
      <title>View Student Records</title>
   </head>
   
   <body>
   <div class=col-md-12>
   <?php echo $__env->make('stud_create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

 </div>

      <table border = 1>
         <tr>
            <td>ID</td>
            <td>Name</td>
            <td>Edit</td>
            <td>Delete</td>
         </tr>
         <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
            <td><?php echo e($user->Id); ?></td>
            <td><?php echo e($user->Name); ?></td>
            <td><a href = 'edit/<?php echo e($user->Id); ?>'>Edit</a></td>
            <td><a href = 'delete/<?php echo e($user->Id); ?>'>Delete</a></td>

         </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
   </body>
</html><?php /**PATH D:\xampp\htdocs\Laravel\example-app\resources\views/stud_view.blade.php ENDPATH**/ ?>