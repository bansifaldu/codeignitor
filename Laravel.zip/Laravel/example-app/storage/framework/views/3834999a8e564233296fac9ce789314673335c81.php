<html>
   <body>
      <h1><?php echo $name; ?></h1>
   </body>
</html><?php /**PATH D:\xampp\htdocs\Laravel\example-app\resources\views/test2.blade.php ENDPATH**/ ?>