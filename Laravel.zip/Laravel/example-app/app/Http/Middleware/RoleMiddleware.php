<?php

namespace App\Http\Middleware;
use Closure;
 class RoleMiddleware {
   public function handle($request, Closure $next, $role) {
      echo "Rolevv: ".$role;
      return $next($request);
   }
}