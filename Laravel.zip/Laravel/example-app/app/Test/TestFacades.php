<?php
   namespace App\Test;
   class TestFacades{
      public function testingFacades() {
         echo "Testing the Facades in Laravel.";
      }
   }
?>