<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

use App\Http\Controllers\TestController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\StudInsertController;
 

Route::get('/test', [TestController::class, 'index']);


Route::get('role',[
    'middleware' => 'Role:bansi',
    'uses' => 'App\Http\Controllers\TestController@index',
 ]);
 Route::get('terminate',[
    'middleware' => 'Terminate',
    'uses' => 'App\Http\Controllers\ABCController@index',
 ]);
 Route::get('profile', [
    'middleware' => 'auth',
    'uses' => 'UserController@showProfile'
 ]);
 
 use App\Http\Controllers\MyController;
Route::resource('my', MyController::class);
 Route::get('/usercontroller/path', [UserController::class, 'showPath'])->middleware('First');


 Route::get('/register',function() {
    return view('register');
 });
 
 Route::post('/user/register',array('uses'=>'App\Http\Controllers\UserRegistration@postRegister'));

 Route::get('/basic_response', function () {
    return 'Hello World';
 });

 Route::get('/test', ['as'=>'testing',function() {
    return view('test');
 }]);
 
 Route::get('redirect',function() {
    return redirect()->route('testing');
 });
 Route::get('insert','App\Http\Controllers\StudViewController@insertform');
Route::post('create','App\Http\Controllers\StudViewController@insert');
Route::get('view-records','App\Http\Controllers\StudViewController@index');

 Route::get('edit/{id}','App\Http\Controllers\StudViewController@show');
Route::post('edit/{id}','App\Http\Controllers\StudViewController@edit');
Route::get('delete/{id}','App\Http\Controllers\StudViewController@destroy');
Route::get('/form',function() {
    return view('form');
 });
 Route::get('/validation','App\Http\Controllers\ValidationController@showform');
 Route::post('/validation','App\Http\Controllers\ValidationController@validateform');
//  Route::get('test', 'App\Http\Controllers\TestController@index');
Route::get('/facadeex', function() {
   return TestFacades::testingFacades();
});

