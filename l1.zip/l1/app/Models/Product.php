<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $fillable = [
        'name', 'detail'
    ];
    
    public function get_product_by_id($id){
        $product = DB::select('select * from product where id = ?',[$id]);
        return $product;

    }
}
