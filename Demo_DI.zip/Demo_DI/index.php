<?php  include('database.php');  
session_start(); 
?>
<a href="category/view_category.php">Category</a>
<br>
<a href="product/view_product.php">Product</a>


 