<?php 
    $db = mysqli_connect('localhost', 'root', '', 'crud_operation');
    

	 
