<?php  include('../database.php');  ?>
<?php

    $name = "";
	
	$update = false;
 
	if (isset($_POST['save']) && $_POST['type']=='add') {
        $product_name = $_POST['product_name'];
        $cat_id = $_POST['cat_id'];
        $cat_id_string= implode(",",$cat_id);
          $sql = "INSERT INTO product ( product_name, cat_id) VALUES ('$product_name', '$cat_id_string')"; 
        mysqli_query($db, $sql);
  		header('location: view_product.php');
	}else if(isset($_POST['save']) && $_POST['type']=='edit'){
        // echo "<pre>";
        // print_r($_POST);exit;
        $product_name = $_POST['product_name'];
        $cat_id = $_POST['cat_id'];
        $cat_id_string= implode(",",$cat_id);
        $id = $_POST['id'];
        $sql = "UPDATE product SET product_name='$product_name',cat_id='$cat_id_string'  WHERE id=$id"; 
        mysqli_query($db, $sql);
         
 		header('location: view_product.php');

    }else{

        if (isset($_GET['delete'])) {
            $id = $_GET['delete'];
            mysqli_query($db, "DELETE FROM product WHERE id=$id");
             header('location: view_product.php');
        }
    }

?>

