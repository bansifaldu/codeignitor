<html>
<link rel="stylesheet" type="text/css" href="../asset/style.css">

<head>
	<title>Product</title>
</head>
<body>
<div>
<a href = "form_product.php">Add</a>
<a href = "../index.php">back</a>
</div>
<table>
	<thead>
		<tr>
			<th>Name</th>
			<th>cat name</th>
 			<th colspan="2">Action</th>
		</tr>
	</thead>
	<?php  include('../database.php');  

	$results = mysqli_query($db, "SELECT * FROM product"); ?>
	<?php while ($row = mysqli_fetch_array($results)) { ?>
		<tr>
			<td><?php echo $row['product_name']; ?></td>
			<td><?php echo $row['cat_id']; ?></td>
			<td>
				<a href="form_product.php?edit=<?php echo $row['id']; ?>" class="edit_btn" >Edit</a>
			
				<a href="product.php?delete=<?php echo $row['id']; ?>" class="del_btn">Delete</a>
			</td>
		</tr>
	<?php } ?>
</table>
 
</body>
</html>