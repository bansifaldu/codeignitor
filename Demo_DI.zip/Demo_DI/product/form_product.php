<!DOCTYPE html>
<html>
 <link rel="stylesheet" type="text/css" href="../asset/style.css">

<head>
<?php 
 if(isset($_GET['edit'])){
?>
	<title>Edit Product</title>
    <?php }else{ ?>
    <title>ADD Product</title>
<?php } ?>
</head>
<body>
<?php 
   include('../database.php');  
 if(isset($_GET['edit'])){
?>
	<h3>Edit Product</h3>
    <?php }else{ ?>
    <h3>ADD Product</h3>
<?php } ?>
	<form method="post" action="product.php" >
		<div class="input-group">
            <label>product Name</label>
            <?php 
                if(isset($_GET['edit'])){
                    $id=$_GET['edit'];
                    $results = mysqli_query($db, "SELECT * FROM Product where id=$id"); 
                    $row = mysqli_fetch_array($results);
                   
                    $id=$row['id'];
                    $product_name= $row['product_name'] ?? '';
                    $cat_id= $row['cat_id'] ?? '';
                    $cat_id_array = explode(",",$cat_id) ;
//   echo "<pre>";
//   print_r($name);
            ?>
            <input type="hidden" name="type" value="edit">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <?php }else{
                 $product_name='';
                 $cat_id='';
                ?>
            <input type="hidden" name="type" value="add">
            <?php } ?>
            <input type="text" name="product_name" value=<?php echo $product_name;  ?>>    

             </div>
            <div class="input-group">
            <label>category name</label>
           
            
                <select name="cat_id[]" id="cat_id" multiple="multiple"  >
                <?php
            $results = mysqli_query($db, "SELECT * FROM category");   
                while ($row = mysqli_fetch_array($results)) { ?>
                    <!-- <option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?></option> -->
                    <option value="<?php echo $row['id']; ?>" <?php echo (isset($cat_id_array) && in_array($row['id'], $cat_id_array) ) ? 'selected="selected"' : "" ?>><?php echo $row['name']; ?></option>

                    <?php } ?>
                </select>

 
                    </div>
		<div class="input-group">
			<button class="btn" type="submit" name="save" >Save</button>
		</div>
	</form>
</body>
</html>