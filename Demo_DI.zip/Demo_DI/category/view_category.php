<html>
<link rel="stylesheet" type="text/css" href="../asset/style.css">

<head>
	<title>Category</title>
</head>
<body>
<div>
<a href = "form_category.php">Add</a>
<a href = "../index.php">back</a>
</div>
<table>
	<thead>
		<tr>
			<th>Name</th>
			<th>Address</th>
			<th colspan="2">Action</th>
		</tr>
	</thead>
	<?php  include('../database.php');  

	$results = mysqli_query($db, "SELECT * FROM category"); ?>
	<?php while ($row = mysqli_fetch_array($results)) { ?>
		<tr>
			<td><?php echo $row['name']; ?></td>
			<td>
				<a href="form_category.php?edit=<?php echo $row['id']; ?>" class="edit_btn" >Edit</a>
			</td>
			<td>
				<a href="category.php?delete=<?php echo $row['id']; ?>" class="del_btn">Delete</a>
			</td>
		</tr>
	<?php } ?>
</table>
	<!-- <form method="post" action="category.php" >
		<div class="input-group">
			<label>Category Name</label>
			<input type="text" name="name" value="">
		</div>
		 
		<div class="input-group">
			<button class="btn" type="submit" name="save" >Save</button>
		</div>
	</form> -->
</body>
</html>