<!DOCTYPE html>
<html>
 <link rel="stylesheet" type="text/css" href="../asset/style.css">
  
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>

<script>
  $(document).ready(function() {
    var name = $('#name').val();
 
$("#basic-form").validate({
    rules: {
        name: {
                        required: true,
                        remote:{
                            url: "chackunique.php",
                            type: "post",
                            data: {
                                username: function () {
                                    return $("#name").val();
                                }
                            }
                        }
                      
                    },
    },
     messages: {
        name: {
                        required: "Name is Required",
                        remote:"User already in use."
                    },
      },
      
    submitHandler: function(form) {
      form.submit();
    }
  });
});
 
 
</script>
<?php 
 if(isset($_GET['edit'])){
?>
	<title>Edit Category</title>
    <?php }else{ ?>
    <title>ADD Category</title>
<?php } ?>
</head>
<body>
<?php 
   include('../database.php');  
 if(isset($_GET['edit'])){
?>
	<h3>Edit Category</h3>
    <?php }else{ ?>
    <h3>ADD Category</h3>
<?php } ?>
	<form method="post" id="basic-form" action="category.php" >
		<div class="input-group">
            <label>Name</label>
            <?php 
                if(isset($_GET['edit'])){
                    $id=$_GET['edit'];
                    $results = mysqli_query($db, "SELECT * FROM category where id=$id"); 
                    $row = mysqli_fetch_array($results);
                   
                    $id=$row['id'];
                    $name= $row['name'] ?? '';
//   echo "<pre>";
//   print_r($name);
            ?>
            <input type="hidden" name="type" value="edit">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <?php }else{
                 $name='';
                ?>
            <input type="hidden" name="type" value="add">
            <?php } ?>
         
         <!-- <input type="text" name="name" value=""> -->

		 		   <input type="text" id="name" name="name" value=<?php echo $name;  ?>>    
                    </div>
		<div class="input-group">
			<button class="btn" type="submit" value="SUBMIT" name="save" >Save</button>
		</div>
	</form>
</body>
</html>
