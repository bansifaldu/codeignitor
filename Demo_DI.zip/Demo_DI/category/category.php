<?php  include('../database.php');  ?>
<?php

    $name = "";
	
	$update = false;
 
	if (isset($_POST['save']) && $_POST['type']=='add') {
		$name = $_POST['name'];
 
		mysqli_query($db, "INSERT INTO category (name) VALUES ('$name')"); 
 		header('location: view_category.php');
	}else if(isset($_POST['save']) && $_POST['type']=='edit'){
        // echo "<pre>";
        // print_r($_POST);exit;
        $name = $_POST['name'];
        $id = $_POST['id'];
        $sql = "UPDATE category SET name='$name' WHERE id=$id"; 
        mysqli_query($db, $sql);
         
 		header('location: view_category.php');

    }else{

        if (isset($_GET['delete'])) {
            $id = $_GET['delete'];
            mysqli_query($db, "DELETE FROM category WHERE id=$id");
             header('location: view_category.php');
        }
    }

?>

