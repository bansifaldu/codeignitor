<?php  include_once('../database.php');  
$name=$_REQUEST['name'];
 
$results = mysqli_query($db, "SELECT count(id) as count FROM category where name = '".$name."'");  
$row = mysqli_fetch_row($results);
  if($row[0] > 0){
    $data= false;
 }else{
    $data= true; 
 }
 echo json_encode($data);
 ?>