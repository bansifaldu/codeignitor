<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_model extends CI_Model{
	
	 

	 
	
	function save_product($product_name,$product_price,$name_file){
		$data = array(
			'product_name' => $product_name,
			'product_price' => $product_price,
			'img' => $name_file 
		);
		$this->db->insert('product',$data);
	}
	function add_cart($product_id,$product_name,$product_price,$qty,$amount){
		$data = array(
			'product_id' => $product_id,
			'product_name' => $product_name,
			'price' => $product_price,
			'qty' => $qty,
			'amount' => $amount 
		);
	 
		$this->db->insert('cart',$data);
	}
	


	function get_products(){
		$this->db->select('product_id,product_name,product_price,img');
		$this->db->from('product');
		 
		$query = $this->db->get();
		return $query;
	}
	function get_products_by_id($product_id){

		$query = $this->db->get_where('product', array('product_id' =>  $product_id));
		 
		return $query;
	}

	function get_carts(){
		$this->db->select('*');
		$this->db->from('cart');
		 
		$query = $this->db->get();
		return $query;
	}
	function update_cart($product_id,$qty,$amount,$cart_id){
		$this->db->set('qty', $qty);
		$this->db->set('amount', $amount);
		$this->db->where('id', $cart_id);
		$this->db->update('cart');

	}
	function get_total(){
		$this->db->select_sum('amount');
		$result = $this->db->get('cart')->row();  
		return $result->amount;
	}
	
	
}