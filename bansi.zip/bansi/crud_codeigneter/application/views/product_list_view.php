<!DOCTYPE html>
<html>
<head>
	<title>Product List</title>
	<link href="<?php echo base_url().'assets/css/bootstrap.css'?>" rel="stylesheet" type="text/css">
	<link href="<?php echo base_url().'assets/css/datatables.css'?>" rel="stylesheet" type="text/css">
</head>
<body>
	<div class="container">

	  <div class="row justify-content-md-center">
	    <div class="col col-lg-8">
	    	<h3>Product List</h3>
	    	<!-- <?php echo $this->session->flashdata('msg');?> -->
			<div class="row">
	    	<a href="<?php echo site_url('product/add_new');?>" class="btn btn-success btn-sm">Add New Product</a> 

	    	<a style="margin-left:10px;" href="<?php echo site_url('product/view_cart');?>" class="btn btn-success btn-sm">View Cart</a><hr/>
			<a href="<?php echo site_url('login/logout');?>" class="btn btn-primary btn-sm">Logout</a><hr/>
			</div>
	      	<table class="table table-striped" id="mytable" style="font-size: 14px;">

			

			 
	      		<thead>
	      			<tr>
	      				<th>No</th>
	      				<th>Product Name</th>
	      				<th>Price</th>
						<th>img</th>
						<th>Add</th>
	      				
	      			</tr>
	      		</thead>
	      		<tbody>
	      			<?php
	      				$no = 0;
	      				foreach ($products->result() as $row):
	      					$no++;
							$img=base_url('assets/img/'.$row->img);  
	      			?>
	      			<tr id=<?php echo $row->product_id;?>>
	      				<td><?php echo $no;?></td>
	      				<td><?php echo $row->product_name;?></td>
 	      				<td><?php echo number_format($row->product_price);?></td>
						<td><img style="height:30px; width:30px;" src = "<?php echo $img;?>"></td>
						<td><button onclick="addcart(<?php echo $row->product_id;?>);" class="btn btn-success" type="button">Add to Cart</button></td>
						<input type="hidden" name="product_id" id="product_id" value="<?php echo $row->product_id;?>">
						<input type="hidden" name="product_name"  id="product_name" value="<?php echo $row->product_name;?>">
						<input type="hidden"  name="product_price" id="product_price"  value="<?php echo $row->product_price;?>">
						
						 
 
	      			</tr>
	      			<?php endforeach;?>
	      		</tbody>
	      	</table>
			
	    </div>
	  </div>

	</div>
	<script type="text/javascript" src="<?php echo base_url().'assets/js/jquery-3.3.1.js'?>"></script>
	<script type="text/javascript" src="<?php echo base_url().'assets/js/bootstrap.js'?>"></script>
	<script type="text/javascript" src="<?php echo base_url().'assets/js/datatables.js'?>"></script>
	<script type="text/javascript">
		 
		function addcart(id_p){
			var product_id= id_p;
			var product_name= $('#product_name').val();
			var product_price= $('#product_price').val();
		 
			$.ajax({
                    url : "<?php echo site_url('product/add_to_cart');?>",
                    method : "POST",
                    data : {product_id: product_id,product_name:product_name,product_price:product_price},
                    async : true,
                    dataType : 'json',
                    success: function(result){
                        alert(result.msg);
                        // var html = '';
                        // var i;
                        // for(i=0; i<data.length; i++){
                        //     html += '<option value='+data[i].subcategory_id+'>'+data[i].subcategory_name+'</option>';
                        // }
                        // $('#sub_category').html(html);

                    }
                });
			 
		}
	</script>
</body>
</html>