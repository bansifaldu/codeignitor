<!DOCTYPE html>
<html>
<head>
	<title>Cart List</title>
	<link href="<?php echo base_url().'assets/css/bootstrap.css'?>" rel="stylesheet" type="text/css">
	<link href="<?php echo base_url().'assets/css/datatables.css'?>" rel="stylesheet" type="text/css">
</head>
<body>
	<div class="container">

	  <div class="row justify-content-md-center">
	    <div class="col col-lg-8">
	    	<h3>Cart List</h3>
	    	<!-- <?php echo $this->session->flashdata('msg');?> -->
	    	<a href="<?php echo site_url('product/index');?>" class="btn btn-success btn-sm">Back</a> 
			<a href="<?php echo site_url('login/logout');?>" class="btn btn-primary btn-sm">Logout</a><hr/>
	      	<table class="table table-striped CampaignGrid" id="mytable" style="font-size: 14px;">
	      		<thead>
	      			<tr>
	      			 
	      				<th>Product Name</th>
	      				<th>Price</th>
	      				<th>Qty</th>
						<th>Amount</th>
	      			</tr>
	      		</thead>
	      		<tbody>
	      			<?php
	      				$no = 0;
	      				foreach ($carts->result() as $row):
	      					$no++;
	      			?>
					  <input type="hidden" name="product_id" id="product_id" value="<?php echo $row->product_id;?>">
						<input type="hidden" name="price" id="price" value="<?php echo $row->price;?>">
						<input type="hidden" name="cart_id" id="cart_id" value="<?php echo $row->id;?>">
	      			<tr id=<?php echo $row->id;?>>
	      				 
	      				<td><?php echo $row->product_name;?></td>
	      				<td><?php echo $row->price;?></td>
	      				<td> <input type="number" class="form-control invent" name="qty" id="qty"  value="<?php echo $row->qty;?>"></td>
	      				<td id='amount_<?php echo $row->id; ?>'><?php echo $row->amount;?></td>
						
	      				 
	      			</tr>
	      			<?php endforeach;?>
	      		</tbody>
	      	</table>
			  <label >Total</label><input readonly type="text" name="total" id="total" value="<?php echo $total;?>">
			  <a href="<?php echo site_url('product/thanks');?>" class="btn btn-success btn-sm">Continue</a> 
	    </div>

		
	  </div>

	</div>
	<script type="text/javascript" src="<?php echo base_url().'assets/js/jquery-3.3.1.js'?>"></script>
	<script type="text/javascript" src="<?php echo base_url().'assets/js/bootstrap.js'?>"></script>
	<script type="text/javascript" src="<?php echo base_url().'assets/js/datatables.js'?>"></script>
	 
	<script type="text/javascript">
		$(document).ready(function(){
			 $('.invent').change(function () {
				var cart_id = $(this).closest('tr').attr('id');
				var value=$(this).parent(); 
				 
                var qty=$(this).val();
				 
				var product_id= $('#product_id').val();
				var price= $('#price').val();
			 
                $.ajax({
                    url : "<?php echo site_url('product/add_qty');?>",
                    method : "POST",
                    data : {qty: qty,product_id:product_id,price:price,cart_id:cart_id},
                    async : true,
                    dataType : 'json',
                    success: function(result){
                      
                        $("#amount_"+cart_id).html(result.amount);
						$('#total').val(result.total);
						 

                    }
                });
                return false;
            }); 
            
		});
	</script>
</body>
</html>