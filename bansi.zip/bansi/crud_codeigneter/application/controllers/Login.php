<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

// namespace App\Controllers;
 
// use CodeIgniter\Controller;
  
class Login extends CI_Controller
{
    public function index()
    {
        // helper(['form']);
        $this->load->view('login');

        // echo view('login');
    } 
 
    public function auth()
    {
        $this->load->model('UserModel');

  
        $user_name = $_POST['name'];
        $password = $_POST['password'];
		$data = $this->UserModel->get_user($user_name,$password);
        $row = $data->row();

        if (isset($row)){
            redirect('product');
            //redirect(base_url().'Product/index');
           // redirect('product_list_view');
        }else{
            redirect('login');
         }
    }
 
    public function logout()
    {
       
        return redirect()->to('/login');
    }
} 