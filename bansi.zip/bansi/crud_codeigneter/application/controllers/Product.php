<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('Product_model','product_model');
		$this->load->library('session');
	}

	function index(){
		 
		$data['products'] = $this->product_model->get_products();
		 
		$this->load->view('product_list_view',$data);
	}
	function add_new(){
		$this->load->view('add_product_view');
	}

	 
	//save product to database
	function save_product(){
		$product_name 	= $this->input->post('product_name',TRUE);
		$product_price 	= $this->input->post('product_price',TRUE);
		 
		if(isset($_FILES['image']['name']) && !empty($_FILES['image']['name'])){

			$config['upload_path']= './assets/img/';
			$config['allowed_types'] = 'gif|jpg|png';
			$config['max_size'] = 10000;
			$config['max_width'] = 10000;
			$config['max_height'] = 10000;
			// echo "<pre>";print_r($_FILES);
			$_FILES['image']['name']=strtotime("now")."_".$_FILES['image']['name'];
			// exit;
			$this->load->library('upload', $config);
			$field_name = "image";
			$img = $this->input->post('image');
			if (!$this->upload->do_upload($field_name))
        {
            $error=array('error'=>$this->upload->display_errors());
			echo "<pre>";print_r($error);
			exit;
            $this->load->view('upload_view',$error);
        }
        else
        {
            $data= $this->upload->data();
			 
            foreach($data as $value)
            {
                $name_file =$value;
                break;
            }
             
        }
			
		}
		 
		 

		$this->product_model->save_product($product_name,$product_price,$name_file);
		$this->session->set_flashdata('msg','<div class="alert alert-success">Product Saved</div>');
		redirect('product');
	}
	function add_to_cart(){
		$product_id = $this->input->post('product_id',TRUE);
		$products = $this->product_model->get_products_by_id($product_id)->result();
		$products_data=$products[0];
		$product_name = $products_data->product_name;
		$product_price = $products_data->product_price;
		$qty = '1';
		$amount = $products_data->product_price;
		 
		$this->product_model->add_cart($product_id,$product_name,$product_price,$qty,$amount);
		$res['msg']="successfull";
		$this->output
        ->set_content_type('application/json')
        ->set_output(json_encode($res));

	}
	function view_cart(){
		 
		$data['carts'] = $this->product_model->get_carts();
		$total=$this->product_model->get_total();
		$data['total'] =$total;
		 
		$this->load->view('cart_list_view',$data);
	}
	function add_qty(){
		$product_id = $this->input->post('product_id',TRUE);
		$qty = $this->input->post('qty',TRUE);
		$price = $this->input->post('price',TRUE);
		$cart_id = $this->input->post('cart_id',TRUE);
		
		$amount=$price*$qty;
		$this->product_model->update_cart($product_id,$qty,$amount,$cart_id);
		$total=$this->product_model->get_total();
		//echo "<pre>";print_r($total);exit;	
		$res['amount']=$amount;
		$res['total']=$total;
		$this->output
        ->set_content_type('application/json')
        ->set_output(json_encode($res));
		
		

	}
	function thanks(){
		$this->load->view('thanks');
	}

	
}